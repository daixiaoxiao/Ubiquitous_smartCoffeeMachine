package groept.ubiquitous.coffeetime;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;

/**
 * Created by SLAM on 24/05/2016.
 */
public class AlarmReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e("Alarm received", "");
        Intent service = new Intent(context, AlarmSound.class);
        context.startService(service);

    }
}
