package groept.ubiquitous.coffeetime;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.TimePicker;

import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.Calendar;

public class MainActivity extends Activity {

    // Initialize context
    Context context;
    AlarmManager alarmManager;
    PendingIntent pendingIntent;

    // Initialize UI elements
    TimePicker timePicker;
    Button setAlarm;
    Button makeCoffee;
    Button turnOff;
    TextView textView;
    Button showerTime;
    Button snooze;
    Button coffeeTime;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        this.context = this;

        // Declaration UI elements
        timePicker = (TimePicker) findViewById(R.id.timePicker);
        setAlarm = (Button) findViewById(R.id.setAlarm);
        makeCoffee = (Button) findViewById(R.id.makeCoffee);
        turnOff = (Button) findViewById(R.id.turnOff);
        textView = (TextView) findViewById(R.id.textView);
        showerTime = (Button) findViewById(R.id.showerButton);
        snooze = (Button) findViewById(R.id.snoozeButton);
        coffeeTime = (Button) findViewById(R.id.coffeeButton);

        // Declare stuff for the Alarm Clock
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        final Calendar alarmTime = Calendar.getInstance();
        final Intent intent = new Intent(MainActivity.this, AlarmReceiver.class);

        // Create onClickListener to select the time of the Alarm Clock
        timePicker.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }

        });

        // Create onClickListener to set the selected time as the alarm time
        setAlarm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timePicker.setEnabled(false);
                turnOff.setEnabled(true);
                intent.putExtra("actie", "on");

                // Set the time of the alarm
                alarmTime.set(Calendar.HOUR_OF_DAY, timePicker.getCurrentHour());
                alarmTime.set(Calendar.MINUTE, timePicker.getCurrentMinute());
                alarmTime.set(Calendar.SECOND, 0);
                alarmTime.set(Calendar.MILLISECOND, 0);

                final int hour = timePicker.getCurrentHour();
                final int minute = timePicker.getCurrentMinute();;

                String minute_string = String.valueOf(minute);
                String hour_string = String.valueOf(hour);

                // Set the Alarm Clock
                pendingIntent = PendingIntent.getBroadcast(MainActivity.this,
                        0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.set(AlarmManager.RTC_WAKEUP,
                        alarmTime.getTimeInMillis(), pendingIntent);

                // Update the UI TextView to show
                // the time that the alarm goes off
                setAlarmText("Alarm set to " + hour_string + ":" + minute_string + ":00");


            }
        });

        makeCoffee.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                // Send signal to raspberry
                // to make a coffee
                new ConnectToPi().execute();
            }
        });

        // Create onClickListener to cancel an Alarm
        turnOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                textView.setText("");
                timePicker.setEnabled(true);
                turnOff.setEnabled(false);
                intent.putExtra("actie", "off");

                alarmManager.cancel(pendingIntent);
            }
        });

        // Create onClickListener to communicate with raspberry (shower)
        showerTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                // Disable alarm
                alarmManager.cancel(pendingIntent);
                sendBroadcast(intent);

                // Send signal to raspberry
                // that users is first going to shower
                new ConnectToPi2().execute();
            }
        });


        // Create onClickListener to snooze the alarm
        snooze.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                // Disable alarm
                alarmManager.cancel(pendingIntent);
                sendBroadcast(intent);

                // Set the time of the alarm + 5 minutes
                alarmTime.set(Calendar.HOUR_OF_DAY, Calendar.getInstance().get(Calendar.HOUR_OF_DAY));
                alarmTime.set(Calendar.MINUTE, Calendar.getInstance().get(Calendar.MINUTE) + 5);
                alarmTime.set(Calendar.SECOND, 0);
                alarmTime.set(Calendar.MILLISECOND, 0);

                // Initialize the new alarm time
                pendingIntent = PendingIntent.getBroadcast(MainActivity.this,
                        0, intent, PendingIntent.FLAG_UPDATE_CURRENT);
                alarmManager.set(AlarmManager.RTC_WAKEUP,
                        alarmTime.getTimeInMillis(), pendingIntent);

            }
        });




        // Create onClickListener to communicate with raspberry (make coffee)
        coffeeTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View V) {
                // Disable alarm
                alarmManager.cancel(pendingIntent);
                sendBroadcast(intent);

                // Send signal to raspberry
                // to make coffee now
                new ConnectToPi().execute();
            }
        });

    }


    public void setAlarmText(String alarmText) {
        textView.setText(alarmText);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }



    private class ConnectToPi extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient=new DefaultHttpClient();
                //HttpPost httppost=new  HttpPost("http://www.w3schools.com/php/demo_echo1.php");
                HttpPost httppost=new  HttpPost("http://10.171.10.2/CoffeeRelay1.php");

                try  {
                    HttpResponse response = httpclient.execute(httppost);
                    String str =  EntityUtils.toString(response.getEntity());
                    Log.d("f", "" + response + " " + str);


                } catch (ClientProtocolException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (IOException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
            }


            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {
            TextView txt = (TextView) findViewById(R.id.textView);
            txt.setText("Executed"); // txt.setText(result);
            // might want to change "executed" for the returned string passed
            // into onPostExecute() but that is upto you
        }

        @Override
        protected void onPreExecute() {}

        @Override
        protected void onProgressUpdate(Void... values) {}
    }


    private class ConnectToPi2 extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... params) {
            HttpClient httpclient=new DefaultHttpClient();
            //HttpPost httppost=new  HttpPost("http://www.w3schools.com/php/demo_echo1.php");
            HttpPost httppost=new  HttpPost("http://10.171.10.2/CoffeeRelay2.php");

            try  {
                HttpResponse response = httpclient.execute(httppost);
                String str =  EntityUtils.toString(response.getEntity());
                Log.d("f", "" + response + " " + str);


            } catch (ClientProtocolException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            } catch (IOException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }


            return "Executed";
        }

        @Override
        protected void onPostExecute(String result) {
            TextView txt = (TextView) findViewById(R.id.textView);
            txt.setText("Executed"); // txt.setText(result);
            // might want to change "executed" for the returned string passed
            // into onPostExecute() but that is upto you
        }

        @Override
        protected void onPreExecute() {}

        @Override
        protected void onProgressUpdate(Void... values) {}
    }
}
