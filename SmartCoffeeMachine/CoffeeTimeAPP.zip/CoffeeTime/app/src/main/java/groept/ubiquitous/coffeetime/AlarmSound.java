package groept.ubiquitous.coffeetime;

import android.annotation.TargetApi;
import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;
import android.widget.Toast;

/**
 * Created by SLAM on 24/05/2016.
 */
public class AlarmSound extends Service {


    MediaPlayer alarmSound;
    private boolean isRunning = false;
    private final IBinder binder = new LocalBinder();

    public class LocalBinder extends Binder {
        AlarmSound getService() {
            // Return this instance of MyService so clients can call public methods
            return AlarmSound.this;
        }
    }


    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @TargetApi(Build.VERSION_CODES.JELLY_BEAN)
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.i("LocalService", "Received start id " + startId);

        if(!this.isRunning) {

            alarmSound = MediaPlayer.create(this, R.raw.maidwiththeflaxenhair);
            alarmSound.start();
            this.isRunning = true;
            Log.i("Alarm started ", this.isRunning + " ");


        } else {
            alarmSound.stop();
            this.isRunning = false;
            Log.i("Alarm stopped ", this.isRunning + " ");
        }
        return START_NOT_STICKY;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        // Tell the user we stopped.
        Toast.makeText(this, "on destroyed called", Toast.LENGTH_SHORT).show();
    }


}
